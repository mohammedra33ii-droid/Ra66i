# Ra66i Rider — Version 2.0

বাংলা Android Delivery Rider অ্যাপ। আগের লোকাল হিসাব ও ফোনে Backup সুবিধা রেখে Packzy Rider browser, multiple tabs এবং face detection যোগ করা হয়েছে।

## ফিচার
- SQLite local database: parcel ও expense তথ্য ফোনে থাকে
- দৈনিক সফল ডেলিভারি, কমিশন এবং মাসিক আয়-ব্যয়/সেভিংস
- JSON backup export ও restore (ফোনে নির্বাচিত জায়গায়)
- Packzy Rider: https://dash.packzy.com/rider
- Multiple browser tabs: নতুন ট্যাব, ট্যাব বদলানো ও বন্ধ করা
- Back / Forward navigation
- Website Face Verification-এর জন্য WebView camera/microphone permission support
- আলাদা Face Detection স্ক্রিন: সামনের ক্যামেরা ও on-device ML Kit দিয়ে মুখ শনাক্ত করে

## Face Scan সম্পর্কে
- Website verification Packzy-এর নিজস্ব verification flow-এর ওপর নির্ভরশীল। Ra66i শুধু অনুমতি দিলে ওয়েবসাইটকে ক্যামেরা/মাইক্রোফোন ব্যবহার করতে দেয়।
- আলাদা Face Detection শুধু ক্যামেরার ফ্রেমে মুখ আছে কি না শনাক্ত করে; কারও পরিচয় যাচাই বা face recognition করে না। এই detection frame ML Kit দিয়ে ডিভাইসেই প্রসেস হয়, সার্ভারে পাঠানো হয় না।
- Camera permission না দিলে এই সুবিধাগুলো কাজ করবে না।

## GitHub Actions দিয়ে APK Build
1. GitHub repository `Ra66i`-তে `Ra66i_Android_Project.zip` আপলোড করুন।
2. আগের `.github/workflows/build-apk.yml` workflow ফাইলটি রাখুন।
3. GitHub → Actions → **Build Ra66i APK** → Run workflow চাপুন।
4. সফল হলে `Ra66i-debug-apk` artifact থেকে `app-debug.apk` ডাউনলোড করুন।

## গুরুত্বপূর্ণ
- এটি source project ZIP, APK নয়। APK GitHub Actions-এ compile হবে।
- Backup ফোনে রাখুন; অ্যাপ uninstall বা ফোন নষ্ট হলে database হারাতে পারে।
- Restore করলে বর্তমান parcel ও expense রেকর্ড Backup-এর রেকর্ড দিয়ে প্রতিস্থাপিত হবে।
- Face Detection কোনো biometric identity verification নয়।
