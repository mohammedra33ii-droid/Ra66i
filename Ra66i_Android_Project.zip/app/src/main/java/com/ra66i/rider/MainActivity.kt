package com.ra66i.rider

import android.Manifest
import androidx.activity.ComponentActivity
import android.os.Bundle
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.graphics.Color
import android.view.View
import android.view.Gravity
import android.webkit.*
import android.widget.*
import android.widget.FrameLayout
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
class DB(ctx: android.content.Context) : SQLiteOpenHelper(ctx, "ra66i.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE parcels(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT, customer TEXT, phone TEXT, amount REAL, commission REAL, status TEXT, date TEXT)""")
        db.execSQL("""CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, amount REAL, date TEXT)""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun addParcel(code:String, customer:String, phone:String, amount:Double, commission:Double, status:String) {
        val v=ContentValues().apply {
            put("code",code); put("customer",customer); put("phone",phone)
            put("amount",amount); put("commission",commission); put("status",status); put("date",today())
        }
        writableDatabase.insert("parcels",null,v)
    }
    fun addExpense(title:String, amount:Double) {
        val v=ContentValues().apply { put("title",title); put("amount",amount); put("date",today()) }
        writableDatabase.insert("expenses",null,v)
    }
    fun today()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
    fun month()=SimpleDateFormat("yyyy-MM",Locale.US).format(Date())
    fun sum(table:String, column:String, where:String):Double {
        val c=readableDatabase.rawQuery("SELECT COALESCE(SUM($column),0) FROM $table WHERE $where",null)
        c.moveToFirst(); val n=c.getDouble(0); c.close(); return n
    }
    fun count(status:String, where:String):Int {
        val c=readableDatabase.rawQuery("SELECT COUNT(*) FROM parcels WHERE status=? AND $where",arrayOf(status))
        c.moveToFirst(); val n=c.getInt(0); c.close(); return n
    }
    fun recent():String {
        val c=readableDatabase.rawQuery("SELECT code,customer,status,commission,date FROM parcels ORDER BY id DESC LIMIT 8",null)
        val b=StringBuilder()
        while(c.moveToNext()) b.append("• ${c.getString(0)} | ${c.getString(1)} | ${c.getString(2)} | ৳${c.getDouble(3).toInt()}\\n")
        c.close()
        return if(b.isEmpty()) "এখনো কোনো পার্সেল যোগ করা হয়নি" else b.toString()
    }
    fun exportJson():String {
        val root=JSONObject()
        for (table in listOf("parcels","expenses")) {
            val arr=JSONArray()
            val c=readableDatabase.rawQuery("SELECT * FROM $table",null)
            while(c.moveToNext()) {
                val o=JSONObject()
                for(i in 0 until c.columnCount) {
                    when(c.getType(i)) {
                        1 -> o.put(c.getColumnName(i),c.getLong(i))
                        2 -> o.put(c.getColumnName(i),c.getDouble(i))
                        4 -> o.put(c.getColumnName(i),JSONObject.NULL)
                        else -> o.put(c.getColumnName(i),c.getString(i))
                    }
                }
                arr.put(o)
            }
            c.close(); root.put(table,arr)
        }
        return root.toString(2)
    }
    fun importJson(s:String) {
        val root=JSONObject(s)
        writableDatabase.beginTransaction()
        try {
            writableDatabase.delete("parcels",null,null); writableDatabase.delete("expenses",null,null)
            for(table in listOf("parcels","expenses")) {
                val arr=root.optJSONArray(table) ?: JSONArray()
                for(i in 0 until arr.length()) {
                    val o=arr.getJSONObject(i); val v=ContentValues()
                    val keys=o.keys()
                    while(keys.hasNext()) {
                        val k=keys.next()
                        if(k=="id") continue
                        val x=o.get(k)
                        when(x) {
                            is Number -> v.put(k,x.toDouble())
                            JSONObject.NULL -> v.putNull(k)
                            else -> v.put(k,x.toString())
                        }
                    }
                    writableDatabase.insert(table,null,v)
                }
            }
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var db: DB
    private lateinit var root: LinearLayout
    private val blue=Color.rgb(23,43,69)
    private val green=Color.rgb(28,130,91)
    private val CREATE_BACKUP=101
    private val RESTORE_BACKUP=102
    private val CAMERA_PERMISSION=501
    private val WEB_PERMISSION=502
    private data class RiderTab(val id:Int, var label:String, val web:WebView)
    private val riderTabs= mutableListOf<RiderTab>()
    private var nextTabId=1
    private lateinit var tabStrip:LinearLayout
    private lateinit var webContainer:FrameLayout
    private var activeTabId=-1
    private var pendingWebPermission:PermissionRequest?=null
    private var cameraProvider:ProcessCameraProvider?=null
    private var faceDetector:FaceDetector?=null
    private var scannerReturnToWeb=false
    private var browserVisible=false
    private var scannerVisible=false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db=DB(this)
        showHome()
    }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun text(s:String,size:Float=16f,bold:Boolean=false,color:Int=Color.DKGRAY):TextView =
        TextView(this).apply { text=s; textSize=size; setTextColor(color); if(bold)setTypeface(null,1); setPadding(dp(4),dp(7),dp(4),dp(7)) }
    private fun button(s:String, action:()->Unit):Button = Button(this).apply { text=s; setOnClickListener { action() } }
    private fun edit(hint:String):EditText=EditText(this).apply { this.hint=hint; textSize=16f; singleLine=true }
    private fun setup(title:String) {
        browserVisible=false
        scannerVisible=false
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(16),dp(18),dp(18)); setBackgroundColor(Color.rgb(247,249,252)) }
        val scroll=ScrollView(this); scroll.addView(root)
        setContentView(scroll)
        root.addView(text("Ra66i  •  $title",24f,true,blue))
        root.addView(text("Delivery Rider Manager",12f,false,Color.GRAY))
    }
    private fun card(s:String) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(10),dp(14),dp(10)); setBackgroundColor(Color.WHITE) }
        box.addView(text(s,16f,true,blue))
        val p=LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(8),0,dp(8)); root.addView(box,p)
    }
    private fun showHome() {
        setup("Dashboard")
        val today=db.today(); val month=db.month()
        val todayCount=db.count("SUCCESS","date='$today'")
        val todayPay=db.sum("parcels","commission","status='SUCCESS' AND date='$today'")
        val monthPay=db.sum("parcels","commission","status='SUCCESS' AND date LIKE '$month%'")
        val monthExpense=db.sum("expenses","amount","date LIKE '$month%'")
        card("আজকের হিসাব\nসফল ডেলিভারি: $todayCount\nকমিশন: ৳${todayPay.toInt()}")
        card("এই মাস\nমোট কমিশন: ৳${monthPay.toInt()}\nখরচ: ৳${monthExpense.toInt()}\nসম্ভাব্য সেভিংস: ৳${(monthPay-monthExpense).toInt()}")
        root.addView(button("Packzy Rider খুলুন") { openRiderTabs() })
        root.addView(button("＋ নতুন পার্সেল যোগ করুন") { showAddParcel() })
        root.addView(button("＋ খরচ যোগ করুন") { showAddExpense() })
        root.addView(button("পার্সেল হিস্টোরি") { showHistory() })
        root.addView(button("ফোনে Backup তৈরি করুন") { createBackup() })
        root.addView(button("Backup Restore করুন") { restoreBackup() })
        root.addView(text("সাম্প্রতিক পার্সেল",18f,true,blue))
        root.addView(text(db.recent(),14f))
        root.addView(text("নোট: ডেটা এই ফোনের SQLite ডাটাবেজে থাকে। অ্যাপ আনইনস্টল বা ফোন নষ্ট হলে আলাদা Backup ফাইল ছাড়া ডেটা হারাতে পারে।",12f,false,Color.GRAY))
    }
    private fun showAddParcel() {
        setup("নতুন পার্সেল")
        val code=edit("পার্সেল ID / ট্র্যাকিং নম্বর")
        val customer=edit("কাস্টমারের নাম")
        val phone=edit("ফোন নম্বর")
        val amount=edit("পার্সেলের COD / মূল্য (৳)")
        val commission=edit("কমিশন (৳), যেমন 25")
        root.addView(code); root.addView(customer); root.addView(phone); root.addView(amount); root.addView(commission)
        val status=Spinner(this)
        status.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("SUCCESS","RETURN","PENDING"))
        root.addView(text("স্ট্যাটাস")); root.addView(status)
        root.addView(button("Save Parcel") {
            val c=code.text.toString().trim()
            if(c.isEmpty() || customer.text.toString().trim().isEmpty() || commission.text.toString().isEmpty()) {
                Toast.makeText(this,"পার্সেল ID, নাম ও কমিশন দিন",Toast.LENGTH_SHORT).show()
            } else {
                db.addParcel(c,customer.text.toString(),phone.text.toString(),
                    amount.text.toString().toDoubleOrNull()?:0.0,
                    commission.text.toString().toDoubleOrNull()?:0.0,status.selectedItem.toString())
                Toast.makeText(this,"পার্সেল সেভ হয়েছে",Toast.LENGTH_SHORT).show(); showHome()
            }
        })
        root.addView(button("ফিরে যান") { showHome() })
    }
    private fun showAddExpense() {
        setup("খরচ যোগ করুন")
        val title=edit("খরচের নাম: পেট্রোল / খাবার / সার্ভিসিং")
        val amount=edit("টাকার পরিমাণ")
        root.addView(title); root.addView(amount)
        root.addView(button("খরচ Save করুন") {
            val n=amount.text.toString().toDoubleOrNull()
            if(title.text.isNullOrBlank() || n==null || n<0) Toast.makeText(this,"সঠিক তথ্য দিন",Toast.LENGTH_SHORT).show()
            else { db.addExpense(title.text.toString(),n); showHome() }
        })
        root.addView(button("ফিরে যান") { showHome() })
    }
    private fun showHistory() {
        setup("পার্সেল হিস্টোরি")
        root.addView(text(db.recent(),16f))
        root.addView(button("Dashboard") { showHome() })
    }
    private fun createBackup() {
        val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type="application/json"; putExtra(Intent.EXTRA_TITLE,"Ra66i-Backup-${db.today()}.json")
        }
        startActivityForResult(i,CREATE_BACKUP)
    }
    private fun restoreBackup() {
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type="application/json" }
        startActivityForResult(i,RESTORE_BACKUP)
    }
    @Deprecated("Deprecated in Android API but compatible with min SDK")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==FILE_CHOOSER) {
            val results=if(resultCode==RESULT_OK && data?.data!=null) arrayOf(data.data!!) else null
            filePathCallback?.onReceiveValue(results); filePathCallback=null; return
        }
        if(resultCode!=RESULT_OK || data?.data==null) return
        val uri=data.data!!
        try {
            if(requestCode==CREATE_BACKUP) {
                contentResolver.openOutputStream(uri)?.use { it.write(db.exportJson().toByteArray(Charsets.UTF_8)) }
                Toast.makeText(this,"Backup তৈরি হয়েছে",Toast.LENGTH_LONG).show()
            } else if(requestCode==RESTORE_BACKUP) {
                val s=contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                db.importJson(s); Toast.makeText(this,"Backup Restore হয়েছে",Toast.LENGTH_LONG).show(); showHome()
            }
        } catch(e:Exception) { Toast.makeText(this,"Backup কাজ হয়নি: ${e.message}",Toast.LENGTH_LONG).show() }
    }

    // Packzy Rider browser with independent WebViews for each tab.
    private fun openRiderTabs() {
        if(riderTabs.isEmpty()) addRiderTab("https://dash.packzy.com/rider")
        showRiderBrowser()
    }
    private fun addRiderTab(url:String="https://dash.packzy.com/rider") {
        val web=WebView(this)
        web.settings.javaScriptEnabled=true
        web.settings.domStorageEnabled=true
        web.settings.mediaPlaybackRequiresUserGesture=false
        web.settings.javaScriptCanOpenWindowsAutomatically=true
        web.settings.setSupportMultipleWindows(false)
        web.settings.allowFileAccess=false
        web.settings.allowContentAccess=true
        web.webViewClient=object:WebViewClient() {
            override fun shouldOverrideUrlLoading(view:WebView, request:WebResourceRequest):Boolean {
                val uri=request.url
                if(uri.scheme=="https" && (uri.host=="dash.packzy.com" || uri.host?.endsWith(".packzy.com")==true)) return false
                if(uri.scheme=="http" || uri.scheme=="https") {
                    startActivity(Intent(Intent.ACTION_VIEW,uri)); return true
                }
                return true
            }
        }
        web.webChromeClient=object:WebChromeClient() {
            override fun onPermissionRequest(request:PermissionRequest) {
                runOnUiThread {
                    val host=request.origin.host
                    val trusted=host=="dash.packzy.com" || host?.endsWith(".packzy.com")==true
                    val allowed=request.resources.filter { it==PermissionRequest.RESOURCE_VIDEO_CAPTURE || it==PermissionRequest.RESOURCE_AUDIO_CAPTURE }
                    if(!trusted || allowed.isEmpty()) { request.deny(); return@runOnUiThread }
                    if(hasCameraAndAudioPermissions()) request.grant(allowed.toTypedArray())
                    else { pendingWebPermission=request; requestPermissions(arrayOf(Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO),WEB_PERMISSION) }
                }
            }
            override fun onReceivedTitle(view:WebView?, title:String?) {
                val tab=riderTabs.firstOrNull { it.web===view }
                if(tab!=null && !title.isNullOrBlank()) { tab.label=title.take(12); if(activeTabId==tab.id) renderTabStrip() }
            }
            override fun onShowFileChooser(webView:WebView?, callback:ValueCallback<Array<Uri>>?, params:FileChooserParams?):Boolean {
                filePathCallback?.onReceiveValue(null); filePathCallback=callback
                return try { startActivityForResult(params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).setType("*/*"),FILE_CHOOSER); true }
                catch(e:Exception) { filePathCallback=null; false }
            }
        }
        val tab=RiderTab(nextTabId++,"Rider ${riderTabs.size+1}",web)
        riderTabs.add(tab)
        web.loadUrl(url)
        activeTabId=tab.id
        showRiderBrowser()
    }
    private var filePathCallback:ValueCallback<Array<Uri>>?=null
    private val FILE_CHOOSER=601
    private fun showRiderBrowser() {
        browserVisible=true
        scannerVisible=false
        val page=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        val top=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setBackgroundColor(blue) }
        fun topButton(label:String, action:()->Unit) { top.addView(Button(this).apply { text=label; textSize=11f; setPadding(dp(2),0,dp(2),0); setOnClickListener { action() } },LinearLayout.LayoutParams(0,dp(48),1f)) }
        topButton("＋ Tab") { addRiderTab() }
        topButton("Face Scan") { startFaceScan() }
        topButton("←") { activeTab()?.web?.let { if(it.canGoBack()) it.goBack() } }
        topButton("→") { activeTab()?.web?.let { if(it.canGoForward()) it.goForward() } }
        topButton("Home") { showHome() }
        page.addView(top)
        val horizontal=HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled=false }
        tabStrip=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setPadding(dp(4),dp(4),dp(4),dp(4)); setBackgroundColor(Color.rgb(235,240,246)) }
        horizontal.addView(tabStrip); page.addView(horizontal,LinearLayout.LayoutParams(-1,dp(48)))
        webContainer=FrameLayout(this)
        riderTabs.forEach { tab ->
            (tab.web.parent as? android.view.ViewGroup)?.removeView(tab.web)
            webContainer.addView(tab.web,FrameLayout.LayoutParams(-1,-1))
            tab.web.visibility=if(tab.id==activeTabId) View.VISIBLE else View.GONE
        }
        page.addView(webContainer,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(page)
        renderTabStrip()
    }
    private fun activeTab()=riderTabs.firstOrNull { it.id==activeTabId }
    private fun renderTabStrip() {
        if(!::tabStrip.isInitialized) return
        tabStrip.removeAllViews()
        riderTabs.forEach { tab ->
            val item=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(8),0,dp(4),0); setBackgroundColor(if(tab.id==activeTabId) Color.WHITE else Color.rgb(220,228,237)) }
            val name=TextView(this).apply { text=tab.label; textSize=12f; setTextColor(blue); maxWidth=dp(110); setOnClickListener { switchRiderTab(tab.id) } }
            val close=TextView(this).apply { text="  ×"; textSize=17f; setTextColor(Color.DKGRAY); setOnClickListener { closeRiderTab(tab.id) } }
            item.addView(name); item.addView(close)
            item.setOnClickListener { switchRiderTab(tab.id) }
            val lp=LinearLayout.LayoutParams(-2,dp(38)); lp.setMargins(dp(3),0,dp(3),0); tabStrip.addView(item,lp)
        }
    }
    private fun switchRiderTab(id:Int) {
        activeTabId=id
        riderTabs.forEach { it.web.visibility=if(it.id==id) View.VISIBLE else View.GONE }
        renderTabStrip()
    }
    private fun closeRiderTab(id:Int) {
        val index=riderTabs.indexOfFirst { it.id==id }; if(index<0) return
        val old=riderTabs.removeAt(index); (old.web.parent as? android.view.ViewGroup)?.removeView(old.web); old.web.stopLoading(); old.web.destroy()
        if(riderTabs.isEmpty()) { addRiderTab(); return }
        if(activeTabId==id) activeTabId=riderTabs[(index-1).coerceAtLeast(0)].id
        showRiderBrowser()
    }
    private fun hasCameraAndAudioPermissions() =
        checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED

    // Native face detection uses the front camera and on-device ML Kit; frames are not uploaded.
    private fun startFaceScan() {
        if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED) {
            scannerReturnToWeb=true; requestPermissions(arrayOf(Manifest.permission.CAMERA),CAMERA_PERMISSION); return
        }
        showFaceScanner()
    }
    private fun showFaceScanner() {
        scannerReturnToWeb=true
        browserVisible=false
        scannerVisible=true
        val layout=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(12,20,32)); setPadding(dp(12),dp(12),dp(12),dp(12)) }
        layout.addView(text("Ra66i • Face Detection",22f,true,Color.WHITE))
        layout.addView(text("সামনের ক্যামেরার দিকে মুখ রাখুন",14f,false,Color.LTGRAY))
        val preview=PreviewView(this).apply { scaleType=PreviewView.ScaleType.FILL_CENTER }
        layout.addView(preview,LinearLayout.LayoutParams(-1,0,1f))
        val status=text("মুখ খোঁজা হচ্ছে…",18f,true,Color.WHITE)
        layout.addView(status)
        layout.addView(button("Rider Dashboard-এ ফিরে যান") { cameraProvider?.unbindAll(); showRiderBrowser() })
        setContentView(layout)
        val options=FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST).setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL).build()
        faceDetector?.close(); faceDetector=FaceDetection.getClient(options)
        val providerFuture=ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider=providerFuture.get(); cameraProvider=provider; provider.unbindAll()
                val cameraPreview=Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
                val analysis=ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                analysis.setAnalyzer(ContextCompat.getMainExecutor(this)) { imageProxy ->
                    val media=imageProxy.image
                    if(media==null) { imageProxy.close(); return@setAnalyzer }
                    val input=InputImage.fromMediaImage(media,imageProxy.imageInfo.rotationDegrees)
                    faceDetector?.process(input)
                        ?.addOnSuccessListener { faces ->
                            status.text=if(faces.isEmpty()) "মুখ পাওয়া যায়নি — ক্যামেরার দিকে তাকান" else "${faces.size}টি মুখ শনাক্ত হয়েছে ✓"
                        }
                        ?.addOnFailureListener { status.text="Face detection চালু করা যায়নি" }
                        ?.addOnCompleteListener { imageProxy.close() } ?: imageProxy.close()
                }
                provider.bindToLifecycle(this,CameraSelector.DEFAULT_FRONT_CAMERA,cameraPreview,analysis)
            } catch(e:Exception) { status.text="ক্যামেরা চালু হয়নি: ${e.message}" }
        },ContextCompat.getMainExecutor(this))
    }
    override fun onRequestPermissionsResult(requestCode:Int, permissions:Array<out String>, grantResults:IntArray) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        if(requestCode==CAMERA_PERMISSION) {
            if(grantResults.isNotEmpty() && grantResults[0]==PackageManager.PERMISSION_GRANTED) showFaceScanner()
            else Toast.makeText(this,"Face Scan-এর জন্য Camera permission প্রয়োজন",Toast.LENGTH_LONG).show()
        } else if(requestCode==WEB_PERMISSION) {
            val request=pendingWebPermission; pendingWebPermission=null
            if(request!=null) {
                if(hasCameraAndAudioPermissions()) request.grant(request.resources.filter { it==PermissionRequest.RESOURCE_VIDEO_CAPTURE || it==PermissionRequest.RESOURCE_AUDIO_CAPTURE }.toTypedArray())
                else request.deny()
            }
        }
    }
    override fun onBackPressed() {
        if(scannerVisible) { cameraProvider?.unbindAll(); showRiderBrowser(); return }
        if(browserVisible && riderTabs.isNotEmpty()) {
            val tab=activeTab()
            if(tab?.web?.canGoBack()==true) { tab.web.goBack(); return }
            showHome(); return
        }
        super.onBackPressed()
    }
    override fun onDestroy() {
        cameraProvider?.unbindAll(); faceDetector?.close(); pendingWebPermission?.deny()
        riderTabs.forEach { it.web.stopLoading(); it.web.destroy() }; riderTabs.clear()
        super.onDestroy()
    }
}
